package com.example.submissionsatugithub.detail.pengikut

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.submissionsatugithub.R
import com.example.submissionsatugithub.UserAdaptor
import com.example.submissionsatugithub.data.model.ResponseUserGithub
import com.example.submissionsatugithub.databinding.FragmentPengikutBinding
import com.example.submissionsatugithub.detail.DetailViewModel
import com.example.submissionsatugithub.utils.Result

class PengikutFragment : Fragment() {

    private var binding: FragmentPengikutBinding? = null
    private val adapter by lazy {
        UserAdaptor {

        }
    }
    private val viewModel by activityViewModels<DetailViewModel>()
    var type = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPengikutBinding.inflate(layoutInflater)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.rvPengikut?.apply {
            layoutManager = LinearLayoutManager(requireActivity())
            setHasFixedSize(true)
            adapter = this@PengikutFragment.adapter
        }

        when (type) {
            PENGIKUT -> {
                viewModel.resultPengikutUser.observe(viewLifecycleOwner, this::manageResultPengikut)
            }

            MENGIKUTI -> {
                viewModel.resultMengikutiUser.observe(viewLifecycleOwner, this::manageResultPengikut)
            }
        }

    }

    private fun manageResultPengikut(state:Result){
        when (state) {
            is Result.Success<*> -> {
                adapter.setData(state.data as MutableList<ResponseUserGithub.ItemsItem>)
            }
            is Result.Error -> {
                Toast.makeText(requireActivity(), state.exception.message.toString(), Toast.LENGTH_SHORT).show()
            }
            is Result.Loading -> {
                binding?.progressBar?.isVisible = state.isLoading
            }
        }
    }

    companion object {
        const val PENGIKUT = 100
        const val MENGIKUTI = 101

        fun newInstance(type: Int) = PengikutFragment()
            .apply {
                this.type = type
            }
    }
}
package com.example.submissionsatugithub.data.remote

import com.example.submissionsatugithub.data.model.ResponseDetailUser
import com.example.submissionsatugithub.data.model.ResponseUserGithub
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.QueryMap

interface GithubService {

    @JvmSuppressWildcards
    @GET("users")
    suspend fun getUserGithub(): MutableList<ResponseUserGithub.ItemsItem>

    @JvmSuppressWildcards
    @GET("users/{username}")
    suspend fun getDetailUserGithub(@Path("username") username : String): ResponseDetailUser

    @JvmSuppressWildcards
    @GET("users/{username}/followers")
    suspend fun getPengikutUserGithub(@Path("username") username : String): MutableList<ResponseUserGithub.ItemsItem>

    @JvmSuppressWildcards
    @GET("users/{username}/following")
    suspend fun getMengikutiUserGithub(@Path("username") username : String): MutableList<ResponseUserGithub.ItemsItem>

    @JvmSuppressWildcards
    @GET("search/users")
    suspend fun searchUserGithub(@QueryMap params: Map<String, Any>):ResponseUserGithub
}
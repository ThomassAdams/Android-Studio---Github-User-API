package com.example.submissionsatugithub.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import coil.load
import coil.transform.CircleCropTransformation
import com.example.submissionsatugithub.R
import com.example.submissionsatugithub.data.model.ResponseDetailUser
import com.example.submissionsatugithub.databinding.ActivityDetailBinding
import com.example.submissionsatugithub.detail.pengikut.PengikutFragment
import com.example.submissionsatugithub.utils.Result
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {
    private lateinit var binding:ActivityDetailBinding
    private val viewModel by viewModels<DetailViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra("username") ?: ""

        viewModel.resultDetailUser.observe(this){
            when (it) {
                is Result.Success<*> -> {
                    val user = it.data as ResponseDetailUser
                    binding.image.load(user.avatarUrl){
                        transformations(CircleCropTransformation())
                    }
                    binding.nama.text = user.name
                    binding.user.text = user.login
                    binding.followers.text = "Followers: ${user.followers}"
                    binding.following.text = "Following: ${user.following}"

                }
                is Result.Error -> {
                    Toast.makeText(this, it.exception.message.toString(), Toast.LENGTH_SHORT).show()
                }
                is Result.Loading -> {
                    binding.progressBar.isVisible = it.isLoading
                }
            }
        }
        viewModel.getDetailUser(username)

        val fragments = mutableListOf<Fragment>(
            PengikutFragment.newInstance(PengikutFragment.PENGIKUT),
            PengikutFragment.newInstance(PengikutFragment.MENGIKUTI)
        )
        val titleFragment = mutableListOf(
            getString(R.string.pengikut),
            getString(R.string.mengikuti)
        )
        val adaptor = DetailAdaptor(this, fragments)
        binding.viewpager.adapter = adaptor

        TabLayoutMediator(binding.tab, binding.viewpager) { tab, posisi ->
            tab.text = titleFragment[posisi]
        }.attach()

        binding.tab.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener{
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == 0) {
                    viewModel.getPengikut(username)
                } else {
                    viewModel.getMengikuti(username)
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

        })

        viewModel.getPengikut(username)

    }
}
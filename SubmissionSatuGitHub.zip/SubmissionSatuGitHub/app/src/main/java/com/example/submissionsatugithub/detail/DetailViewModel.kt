package com.example.submissionsatugithub.detail

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.submissionsatugithub.data.remote.ApiClient
import com.example.submissionsatugithub.utils.Result
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch

class DetailViewModel : ViewModel() {
    val resultDetailUser = MutableLiveData<Result>()
    val resultPengikutUser = MutableLiveData<Result>()
    val resultMengikutiUser = MutableLiveData<Result>()


    fun getDetailUser(username : String) {
        viewModelScope.launch {
            flow {
                val response = ApiClient
                    .githubService
                    .getDetailUserGithub(username)

                emit(response)
            }.onStart {
                resultDetailUser.value = Result.Loading(true)
            }.onCompletion {
                resultDetailUser.value = Result.Loading(false)
            }.catch {
                resultDetailUser.value = Result.Error(it)
            }.collect {
                resultDetailUser.value = Result.Success(it)
            }
        }
    }

    fun getPengikut(username: String){
        viewModelScope.launch {
            flow {
                val response = ApiClient
                    .githubService
                    .getPengikutUserGithub(username)

                emit(response)
            }.onStart {
                resultPengikutUser.value = Result.Loading(true)
            }.onCompletion {
                resultPengikutUser.value = Result.Loading(false)
            }.catch {
                resultPengikutUser.value = Result.Error(it)
            }.collect {
                resultPengikutUser.value = Result.Success(it)
            }
        }
    }

    fun getMengikuti(username: String){
        viewModelScope.launch {
            flow {
                val response = ApiClient
                    .githubService
                    .getMengikutiUserGithub(username)

                emit(response)
            }.onStart {
                resultMengikutiUser.value = Result.Loading(true)
            }.onCompletion {
                resultMengikutiUser.value = Result.Loading(false)
            }.catch {
                resultMengikutiUser.value = Result.Error(it)
            }.collect {
                resultMengikutiUser.value = Result.Success(it)
            }
        }
    }
}